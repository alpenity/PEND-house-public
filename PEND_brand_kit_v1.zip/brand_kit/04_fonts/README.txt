P·E·N·D house — Шрифти
========================

Raleway (заголовки, логотип)
  raleway-200.ttf — ExtraLight
  raleway-300.ttf — Light
  raleway-400.ttf — Regular

Mulish (основний текст)
  mulish-300.ttf — Light
  mulish-400.ttf — Regular
  mulish-500.ttf — Medium

Джерело: Google Fonts (OFL ліцензія, безкоштовне комерційне використання)

Підключення в CSS:
  @font-face { font-family: 'Raleway'; font-weight: 200; src: url('raleway-200.ttf'); }
  @font-face { font-family: 'Raleway'; font-weight: 300; src: url('raleway-300.ttf'); }
  @font-face { font-family: 'Raleway'; font-weight: 400; src: url('raleway-400.ttf'); }
  @font-face { font-family: 'Mulish';  font-weight: 300; src: url('mulish-300.ttf'); }
  @font-face { font-family: 'Mulish';  font-weight: 400; src: url('mulish-400.ttf'); }
  @font-face { font-family: 'Mulish';  font-weight: 500; src: url('mulish-500.ttf'); }
