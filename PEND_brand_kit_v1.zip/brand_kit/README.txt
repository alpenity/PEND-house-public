P·E·N·D house — Brand Kit v1
==============================
Hush bar · Київ · Велика Васильківська, 58 · Since 2005

ЗМІСТ
-----

01_guideline/
  PEND_brand_guideline_v1.html   — Технічний бренд-гайдлайн (автономний, всі
                                    шрифти і зображення вбудовані)

02_logo/
  PEND_logo_cream_on_ink.svg     — Основний логотип (крем на темному)
  PEND_logo_cream_no_bg.svg      — Без фону (PNG-прозорість)
  PEND_logo_ink_on_cream.svg     — Інверсія (на світлому тлі)
  PEND_logo_brass_no_bg.svg      — Латунь (для тиснення)
  README.txt

03_keyhole/
  PEND_keyhole_red.svg           — Щілина червона, без фону
  PEND_keyhole_cream.svg         — Щілина кремова, без фону
  PEND_keyhole_brass.svg         — Щілина латунь, без фону
  PEND_keyhole_red_on_ink.svg    — Щілина червона на Ink
  README.txt

04_fonts/
  raleway-200.ttf / 300 / 400    — Заголовки, логотип
  mulish-300.ttf  / 400 / 500    — Основний текст
  README.txt

05_colors/
  PEND_colors.txt                — Палітра: HEX + RGB + правила

06_patterns/
  PEND_pattern_keyhole_red_tile.svg    — Тайл: щілина червона
  PEND_pattern_keyhole_brass_tile.svg  — Тайл: щілина латунь
  PEND_patterns_css.txt                — CSS для всіх 4 патернів
  README.txt

07_textures/
  PEND_textures_css.txt          — Film Grain + Brass Foil: HTML/CSS код
  README.txt

ВАЖЛИВО
-------
· SVG-логотипи використовують шрифт Raleway. Для production — конвертуй текст
  у криві (Outline) у Figma або Illustrator
· Гайдлайн повністю автономний — відкривається без інтернету
· Всі файли: © P·E·N·D house. Тільки для підрядників проєкту
